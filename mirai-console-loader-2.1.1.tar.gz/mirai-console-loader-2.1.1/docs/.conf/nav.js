module.exports = {
    text: 'mirai-console-loader',
    link: '/',
    items: [
        {text: '主页', link: '/'},
        {text: 'MCL模块', link: '/Module.html'},
        {text: 'MCL插件', link: '/Plugin.html'},
    ],
};
